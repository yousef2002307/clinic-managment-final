
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>


<section class="cliview">
    <div>
    <p> username : <?php echo e($cli->username); ?></p>
    </div>
    <div>
        <p>address: <?php echo e($cli->b_no); ?>/<?php echo e($cli->street); ?>/<?php echo e($cli->city); ?></p>
    </div>
    <div>
        <p>joined AT: <?php echo e($cli->created_at); ?> </p>
    </div>
    <div>
        <p>name: <?php echo e($cli->name); ?> </p>
    </div>
    <div>
        <p>email: <?php echo e($cli->email); ?> </p>
    </div>
    <div>
        <p> phone : <?php echo e($cli->phone); ?> </p>
    </div>
    <div class="pend">
        <?php if($cli->pending): ?>
        <a href="<?php echo e(url("/adminactivatecli2/$cli->id")); ?>" class="btn">activate</a>
        <?php else: ?>
        
        <a href="<?php echo e(url("/adminpendingcli2/$cli->id")); ?>" class="btn">disable this user for review</a>
        <?php endif; ?>
        
            <a class="aclose" href='<?php echo e(url("/adminclidel2/$cli->id")); ?>'>delete</a>
    
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/admin/userview.blade.php ENDPATH**/ ?>