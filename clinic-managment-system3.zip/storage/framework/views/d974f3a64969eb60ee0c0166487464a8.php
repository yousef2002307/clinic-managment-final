<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if($status ): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Hello doc</strong> Youhave missing data please complete you profile to make it easier and more attractive to patient <a href="<?php echo e(url('/doceditprofile')); ?>">here</a>.
 <button class="btn donotshow">do not show this agian</button>
 <input type="hidden" class="xuz" value="<?php echo e(session('docid')); ?>"/>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<!--skllskd-->
<?php if($count == 0): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  no patients today
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php if($count == -1): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  no work today go have fun
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>

<?php if($count > 0): ?>
<section class="jocards">
  <div class="container">
    <div class="jocard">
      

    </div>
     
<div class="jo22">
  <form action="<?php echo e(url('/examination')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <input type="hidden" name="hid" class="doc-hid" value="<?php echo e($appointment->patients->id); ?>">
    <input type="hidden" name="hid2" class="doc-hid2" value="<?php echo e($appointment->id); ?>">
  <button type="submit" class="exa hvr-bounce-to-right theme_btn_two  ">start examination</button>

  </form>
</div>
  </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  


$timeint = 1000
setInterval(() => {
   

$.ajaxSetup({
            headers : {
                'X-CSRF-TOKEN' :$("input[type='hidden']").attr("value")
            }
    });
    
  
      ///////////////////
      $.ajax({
        method: "post",
        url: "<?php echo e(url('/reshome2')); ?>" , // that is blade function to go to specific route
//or you can pass a parameter to url func like this
//  url: `<?php echo e(url('/test2/${userid}')); ?>`

        data : {}, //the data you sed to index method
        success: function (response) {
          document.querySelector('.jocard').innerHTML = ``
         if(response.success){
           $(".doc-hid").val(response.result[0].patients.id)
           $(".doc-hid2").val(response.result[0].id)
            let srcjo = response.result[0].patients.image == 'x' ? "<?php echo e(asset('images/pic-1.jpg')); ?>" : "<?php echo e(asset('images/')); ?>/"+  response.result[0].patients.image 
          
            document.querySelector('.jocard').innerHTML +=`
           
        <span>
          #${response.result[0].queue_num}
        </span>
       
        <img src="${srcjo}" alt="">
       
      
        <strong class="d-block mb-4 text-center">
         name:${response.result[0].patients.name}
        </strong>
        <strong class="d-block text-center">
          status:  ${response.result[0].revisit?"revisit" : "visit"}
         </strong>
        <div class="act ${response.result[0].active ? "act-green" : "act-red"}">
         ${response.result[0].active ? "active" : "non-active"}
        </div>
        
    
   
            `












         }

       
         
        }
       });


      }, $timeint);






</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/cli/dochome.blade.php ENDPATH**/ ?>