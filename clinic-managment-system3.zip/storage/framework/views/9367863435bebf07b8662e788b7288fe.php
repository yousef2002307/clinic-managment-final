
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<h2 class="text-center mt-5 mb-5">search patient</h2>
<form action="<?php echo e(url('/searchuser')); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    <?php echo method_field("post"); ?>
   
    
   <input type="text" name="name" class="form-control" placeholder="enter exact username of patient"/>
   
    
      
    <button type="submit" class="btn btn-primary">search</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/admin/su.blade.php ENDPATH**/ ?>