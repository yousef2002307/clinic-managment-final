<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

<main id="main">

    <!-- ======= About Section ======= -->
    <section id="edit" class="edit">
       <div class="container">
       <h2 class="text-center">edit profile</h2>
       <form action="<?php echo e(url('/cliupdate')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
        <div class="form-group">
          <label for="exampleInputEmail1">Email address</label>
          <input value="<?php echo e($patient->email); ?>" required type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input type="password" name='password' class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <div class="form-group">
            
            <input value="<?php echo e($patient->password); ?>" type="hidden" name="password2" class="form-control" id="exampleInputPassword1" placeholder="Password">
          </div>
       
        <div class="form-group">
            <?php $sliced3 =  $patient->numofvisits; ?>
            <label for=""> num of visits</label>
            <select class="form-control mb-4" name="visit" id="" required>
              <option value="2" <?php echo e($sliced3 == '2' ? "selected" : ""); ?>>2(1$)</option>
              <option value="3"  <?php echo e($sliced3 == '3' ? "selected" : ""); ?>>3(2$)</option>
              <option value="10" <?php echo e($sliced3 == '10' ? "selected" : ""); ?>>10(30$)</option>
              <option value="20" <?php echo e($sliced3 == '20' ? "selected" : ""); ?>>20(41$)</option>
              <option value="30"  <?php echo e($sliced3 == '30' ? "selected" : ""); ?>>30(72$)</option>
              <option value="50" <?php echo e($sliced3== '50' ? "selected" : ""); ?>>50(100$)</option>
              <option value="1000" <?php echo e($sliced3 == '1000' ? "selected" : ""); ?>>infinite(501$)</option>
            </select>
          </div>
          <input type="hidden" name="hidden" value="<?php echo e($patient->id); ?>">
          <div class="form-group">
            <label for="exampleInputEmail1">name</label>
            <input value="<?php echo e($patient->name); ?>"required type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name">
           
          </div>
          

          <div class="form-group">
            <label for="exampleInputPassword1">description</label>
            <input value="<?php echo e($patient->desc2); ?>" required type="text" name="desc2" class="form-control"  placeholder="enter her all your qulifcatuon">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">b_no</label>
            <input value="<?php echo e($patient->b_no); ?>"required  name="b_no" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter b_no">
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">street</label>
            <input value="<?php echo e($patient->street); ?>"required type="text" class="form-control" id="exampleInputPassword1" name="street" placeholder="street">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">city</label>
            <input value="<?php echo e($patient->city); ?>" required name="city" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="city">
            
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">phone</label>
            <input value="<?php echo e($patient->phone); ?>" required type="number" name="phone"  class="form-control" id="exampleInputPassword1" placeholder="phone">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">price of visit</label>
            <input value="<?php echo e($patient->price); ?>" required name="price" type="number" class="form-control visit" id="exampleInputEmail1" aria-describedby="emailHelp" >
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">price of revisit</label>
            <input  value="<?php echo e($patient->price2); ?>" required type="number" name="price2" class="form-control visit" id="exampleInputPassword1">
          </div>
          <?php $sliced = explode(' ', $patient->work_days)[0]; ?>
          <?php $sliced2 = explode(' ',$patient->work_days)[2]; ?>
          <div class="form-group">
            <label>work days from</label>
            <select name="dayf" id="" required>
               
              <option value="Sunday" <?php echo e($sliced == 'Sunday' ? "selected" : ""); ?>>Sunday(0)</option>
              <option value="Monday"  <?php echo e($sliced == 'Monday' ? "selected" : ""); ?>>Monday(1)</option>
              <option value="Tuesday" <?php echo e($sliced == 'Tuesday' ? "selected" : ""); ?>>Tuesday(2)</option>
              <option value="Wednesday" <?php echo e($sliced == 'Wednesday' ? "selected" : ""); ?>>Wednesday(3)</option>
              <option value="Thursday" <?php echo e($sliced == 'Thursday' ? "selected" : ""); ?>>Thursday(4)</option>
              <option value="Friday"   <?php echo e($sliced == 'Friday' ? "selected" : ""); ?>>Friday(5)</option>
              <option value="Saturday"   <?php echo e($sliced == 'Saturday' ? "selected" : ""); ?>>Saturday(6)</option>
            </select>
            <label>to</label>
            <select name="dayt" id="" required>
                <option value="Sunday" <?php echo e($sliced2 == 'Sunday' ? "selected" : ""); ?>>Sunday(0)</option>
              <option value="Monday"  <?php echo e($sliced2 == 'Monday' ? "selected" : ""); ?>>Monday(1)</option>
              <option value="Tuesday" <?php echo e($sliced2 == 'Tuesday' ? "selected" : ""); ?>>Tuesday(2)</option>
              <option value="Wednesday" <?php echo e($sliced2 == 'Wednesday' ? "selected" : ""); ?>>Wednesday(3)</option>
              <option value="Thursday" <?php echo e($sliced2 == 'Thursday' ? "selected" : ""); ?>>Thursday(4)</option>
              <option value="Friday"   <?php echo e($sliced2 == 'Friday' ? "selected" : ""); ?>>Friday(5)</option>
              <option value="Saturday"   <?php echo e($sliced2== 'Saturday' ? "selected" : ""); ?>>Saturday(6)</option>
            </select>
          </div>
          <div class="form-group">
            
            <div>work hours from</div>
            <input name="timef" value="<?php echo e($patient->works_from); ?>" type="time" required>
            <div>to</div>
            <input name="timet" value="<?php echo e($patient->works_to); ?>" type="time" required>
          </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
       </div>
       </section>
       </main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/cli/edit2.blade.php ENDPATH**/ ?>