<div class='alert alert-danger'>your account is under review due to reports contact us through contact-us form that we will redirect you to it , come back later  </div>
<script>
    setTimeout(function() {
    window.location.href = "<?php echo e(url('/contact')); ?>";  // Replace with your desired route
    }, 5000); // Delay in milliseconds (5 seconds in this case)
    </script><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/pending.blade.php ENDPATH**/ ?>