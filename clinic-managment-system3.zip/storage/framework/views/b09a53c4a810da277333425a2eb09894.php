
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>


<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center mb-5">
                <h2 class="heading-section">clinics<Scadule</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-wrap">
                    <table class="table table-responsive-xl table-striped">
                      <thead>
                        <tr>
                          <th>name of clinic</th>
                          <th>doc name</th>
                          
                          <th>address</th>
                          <th>email</th>
                          <th>phone of doctor</th>
                          <th>status</th>
                         <th>operations</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $cli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="alert" role="alert">
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e(isset($item->doctors[0]) ? $item->doctors[0]->name : ''); ?></td>

                          <td><?php echo e($item->b_no); ?>/<?php echo e($item->street); ?>/<?php echo e($item->city); ?></td>
                          <td><?php echo e($item->email); ?></td>
                          <td><?php echo e(isset($item->doctors[0]) ? $item->doctors[0]->phone : ''); ?></td>
                         
                          <?php if($item->pending): ?>
                          <td>pending</td>
                           <?php else: ?>   
                           <td>active</td>
                          <?php endif; ?>
                       
                          <td>
                            
                              <button type="button" class="close" >
                                <a class="aclose" href='<?php echo e(url("/adminclidel/$item->id")); ?>'> <span aria-hidden="true"><i class="fa fa-close"></i></span></a>
                          </button>
                          <button type="button" class=""  aria-label="edit">
                            <a href='<?php echo e(url("/admincliview/$item->id")); ?>'>view info</a>
                          </button>
                        </td>
                  
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      </tbody>
                    </table>
                  
                    <?php echo $cli->withQueryString()->links('pagination::bootstrap-5'); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/admin/clinics.blade.php ENDPATH**/ ?>