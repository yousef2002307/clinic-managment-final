<?php $__env->startSection('home'); ?>
<section class="home py-4">
   <div class="overlay"></div>
 <div class="j-buttons">
    <button><a href="<?php echo e(url('/doclogin')); ?>">continue as doctor</a></button>
    <button><a href="<?php echo e(url('/reslog')); ?>">continue as receptionist</a></button>
 </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/choose.blade.php ENDPATH**/ ?>