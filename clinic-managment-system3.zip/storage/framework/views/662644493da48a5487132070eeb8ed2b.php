<?php $__env->startSection('con'); ?>

<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

 <section class="form-container">
  <?php if(!$patient->creditcardnumber || !$patient->ccv): ?>
  <div class="" style="
    position: fixed;
    bottom: 31px;">to pay online fill all our credit card data from  <a style="cursor: pointer;
    display: inline-block;
    position: relative;
    z-index: 77777777777;" href="<?php echo e(url("/usereditprofile")); ?>">here</a></div>
  <?php endif; ?>
  <!-- <form action="" method="post" enctype="multipart/form-data"> -->
    <p class="appoint" style="font-weight: 700; font-size: 200%; color: black; margin-top: 50px; position: fixed; top: 10%;">Make appointment</p>
   
    <div class="content" style="color: black; margin-top: 50px; position: fixed; top: 20%; padding-right: 20%;">

        <div class="container text-left">
          <div class="row justify-content-center">
            <div class="col-lg-3">
              <?php if(!isset($editid)): ?>
              <form action="<?php echo e(route('user.docappoi2')); ?>" method="POST" class="row">
                <?php else: ?>
                <form action="<?php echo e(route('user.update')); ?>" method="POST" class="row">
                <?php endif; ?>
                  <?php echo csrf_field(); ?>
                  <?php echo method_field("post"); ?>
                <div class="col-md-12">
                  <div class="form-group">
                    <?php if(!isset($editid)): ?>
                      <input type="hidden" name="hidden" value="<?php echo e($id); ?>">
                      <?php else: ?>
                      <input type="hidden" name="hidden" value="<?php echo e($editid); ?>">
                      <?php endif; ?>
                   
                      <label for="input_from">Select date</label>
                      <?php if(!isset($editid)): ?>
                    <input  name="date" type="text" class="form-control" id="input" style="font-size: 100%; color: black;" >
                    <?php else: ?>
                    <input value="<?php echo e($appoiment->date); ?>"  name="date" type="text" class="form-control" id="input" style="font-size: 100%; color: black;" >
                    <?php endif; ?>
                    <?php if(!isset($editid)): ?>
                    <?php if($patient->creditcardnumber & $patient->ccv): ?>
                    <input type="radio" name="radio" value="0">pay  visa
                    <?php endif; ?>
                   
                    <input type="radio" name="radio" value="1" checked>pay  cash
                    <?php else: ?>
                    <?php if($patient->creditcardnumber & $patient->ccv): ?>
                    <input type="radio" name="radio" value="0" <?php echo e($appoiment->payment_status == 0 ?"checked" : ""); ?>>pay  visa
                    <?php endif; ?>
                   
                    
                    <input type="radio" name="radio" value="1" <?php echo e($appoiment->payment_status == 1 ?"checked" : ""); ?>>pay  cash
                    <?php endif; ?>
                    <button type="submit" style="margin-left: 110px;"  class="inline-btn">check availability</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
              
        </div>
      </div>
    
  <!-- </form> -->
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/users/appoi.blade.php ENDPATH**/ ?>