<?php $__env->startSection('home'); ?>
<?php if($errors->any()): ?>
  <?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<section class="jo4">
    <form class="d-flex login" action="<?php echo e(route('doclogin.post')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
        <div class="first mx-auto">
            <div class="title">doctor login</div>
            <div class="">
               
                <input class="form-control" name="username" type="text" placeholder="Enter your username" required>
              </div>
              

              <div class="">
              
                
                <input class="form-control" name="password" type="password" placeholder="Enter your password(at least 6 character and one is alphaphetic)" required>
              </div>
           
        </div>
    
        <div class="button input-box">
            <input type="submit" value="login">
          </div>
          <div class="text" style="    margin: auto;"><a href="<?php echo e(url('/forget3')); ?>">Forgot Password?</a></div>
    </form>
   
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/doclogin.blade.php ENDPATH**/ ?>