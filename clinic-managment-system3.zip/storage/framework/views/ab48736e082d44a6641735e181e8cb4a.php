<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<main id="main">

    <!-- ======= About Section ======= -->
    <section id="edit" class="edit">
       <div class="container">
       <h2 class="text-center">edit profile</h2>
       <form action="<?php echo e(url('resupdate')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
        <div class="form-group">
          <label for="exampleInputEmail1">Email address</label>
          <input value="<?php echo e($patient->email); ?>" type="text" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input type="password" name='password' class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <div class="form-group">
            
            <input value="<?php echo e($patient->password); ?>" type="hidden" name="password2" class="form-control" id="exampleInputPassword1" placeholder="Password">
          </div>
      
          <input type="hidden" name="hidden" value="<?php echo e($patient->id); ?>">
          <div class="form-group">
            <label for="exampleInputEmail1">name</label>
            <input value="<?php echo e($patient->name); ?>" type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name">
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">username</label>
            <input value="<?php echo e($patient->username2); ?>" required type="text" name="username" class="form-control" id="exampleInputPassword1" placeholder="username">
          </div>

         
          
          <div class="form-group">
            <label for="exampleInputPassword1">phone</label>
            <input value="<?php echo e($patient->phone); ?>" type="number" name="phone"  class="form-control" id="exampleInputPassword1" placeholder="phone">
          </div>
        
          
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
       </div>
       </section>
       </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/cli/resedit.blade.php ENDPATH**/ ?>