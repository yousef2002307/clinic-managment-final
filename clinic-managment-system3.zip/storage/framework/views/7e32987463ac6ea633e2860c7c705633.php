<?php $__env->startSection('con'); ?>
<section class="courses">

    <h1 class="heading">doctors</h1>
    <form method="GET" action="<?php echo e(url('/userhome')); ?>">
      <label for="order">Sort Order:</label>
      <select name="order" id="order">
          
          <option value="rating" <?php echo e(request('order') == 'rating' ? 'selected' : ''); ?>  >rating</option>
          <option value="asc" <?php echo e(request('order') == 'asc' ? 'selected' : ''); ?>>Ascending(oldest)</option>
          <option value="desc" <?php echo e(request('order') == 'desc' ? 'selected' : ''); ?>>Descending(newest)</option>
      </select>
      <button type="submit">Apply</button>
    </form>
    <div class="box-container">
      <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="box" data-id="<?php echo e($item->id); ?>">
         <div class="tutor">
            <?php if($item->image): ?>
            <img src="images/<?php echo e($item->image); ?>" alt="">

            <?php else: ?>
            <img src="images/pic-2.jpg" alt="">
            <?php endif; ?>
          
            <div class="info">
               <h3><?php echo e($item->username); ?></h3>
               <?php if($item->rating==0): ?>
               <span><i class="fa-solid fa-star" style="color: gold"></i>0(0)</span>
               <?php else: ?> 
               <span><i class="fa-solid fa-star" style="color: gold"></i><?php echo e(number_format($item->rating / $item->numofrating,1)); ?>(<?php echo e($item->numofrating); ?>)</span>
               <?php endif; ?>
              
               <!-- <span>21-10-2022</span> -->
            </div>
         </div>
         <!-- <div class="thumb">
            <img src="images/thumb-1.png" alt="">
            <span>10 videos</span>
         </div> -->
         <h3 class="title">name of clinic : <?php echo e($item->cli->name); ?></h3>
         <h3 class="title">name of doctor : <?php echo e($item->name); ?></h3>
         <h3 class="title">address of clinic : <?php echo e($item->cli->b_no); ?>,<?php echo e($item->cli->city); ?>,<?php echo e($item->cli->street); ?></h3>
         <h3 class="title">work hours :( <?php echo e(substr($item->cli->works_from,0,5)); ?> to <?php echo e(substr($item->cli->works_to,0,5)); ?>)</h3>
         <h3 class="title">work days : <?php echo e($item->cli->work_days); ?></h3>
         <a href="<?php echo e(route('user.docpro', ['id' => $item->id])); ?>" class="inline-btn">view info</a>
      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
      



    </div>
  
 </section>
 <?php echo $doctors->withQueryString()->links('pagination::bootstrap-5'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/users/main.blade.php ENDPATH**/ ?>