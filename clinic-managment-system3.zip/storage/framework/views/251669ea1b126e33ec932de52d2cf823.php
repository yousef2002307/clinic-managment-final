<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<section class="courses">

    <h1 class="heading">patients</h1>

    <div class="box-container">
<?php $__currentLoopData = $pats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="box">
    <div class="tutor">
        <?php if($pat->patients->image == 'x'): ?>
      <img src="<?php echo e(asset('images/pic-1.jpg')); ?>" alt="">
      <?php else: ?> 
      <img src="<?php echo e(asset('images/'.$pat->patients->image)); ?>" alt="">

      <?php endif; ?>
       <div class="info">
          <h3><?php echo e($pat->patients->name); ?></h3>
          <!-- <span>21-10-2022</span> -->
       </div>
    </div>
    <!-- <div class="thumb">
       <img src="images/thumb-1.png" alt="">
       <span>10 videos</span>
    </div> -->
  
    <a href="<?php echo e(url('/viewinfo',$pat->patients->id)); ?>" class="inline-btn">view info</a>
  
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      

 
    </div>
  
 </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/cli/docpat.blade.php ENDPATH**/ ?>