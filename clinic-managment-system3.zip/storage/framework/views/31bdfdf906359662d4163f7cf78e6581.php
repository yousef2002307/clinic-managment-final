<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success3')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success3')); ?>

  </div>
<?php endif; ?>
<section class="form-container">

    <form action="<?php echo e(url('/addguest2')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
       <h3>Make appointment</h3>
       <p>Name</p>
       <input type="text" name="name" placeholder="" maxlength="50" class="box">

       <p>Please select the condition:</p>
        <input type="radio" id="non-errogent" name="cond" value="0" checked>
        <label for="non-errogent" style="color: #ccc">non-errogent</label><br>
        <input type="radio" id="errogent" name="cond" value="1">
        <label for="errogent" style="color: #ccc">errogent</label><br>
      <input type="submit" style="color: #ccc" value="Make appointment" name="submit" class="btn">

    </form>

 </section>
 <span class="d-block text-center" style="color: #ccc">the system will calculate price of non-errogent:(price of visit + price of revisit)</span>
<span class="d-block text-center" style="color: #ccc">the system will calculate price of non-errogent:(price of visit + price of revisit) * 2</span>



 <?php $__env->stopSection(); ?>





<?php echo $__env->make('res.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/res/addguest.blade.php ENDPATH**/ ?>