
<?php $__env->startSection('con'); ?>

<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<h2 class="text-center mt-5 mb-5" style="    color: #c50d0ddd;">appoiments tracker</h2>
<?php if(!count($app)): ?>


<div class="alert alert-danger mb-5">
   you have no appoiments today
</div>

<?php else: ?>




<?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-warning alert-dismissible fade show mt-5 mb-5" role="alert">
    <strong>Hello  </strong> your appoiments with <?php echo e($item->cli->name); ?> there <strong><?php echo e($arr[$key]); ?> </strong>before you and your queue number is  <strong><?php echo e($item->queue_num); ?></strong>.
   <?php if($arr2[$key]): ?>
   <strong>clinic has opened</strong>    
   <?php else: ?>
   <strong>clinic has not opened </strong> 
   <?php endif; ?>
   
  </div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 you need to refresh for any updates

  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/users/appt.blade.php ENDPATH**/ ?>