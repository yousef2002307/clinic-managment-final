
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>



<div class="gridjo">
    <div class="item">
        num of clinics : <span><?php echo e($cli); ?></span>
    </div>
    <div class="item"> num of patients : <span> <?php echo e($pat); ?></span></div>
    <div class="item"> num of doctors : <span> <?php echo e($doc); ?></span></div>
    <div class="item"> num of receptionists : <span> <?php echo e($res); ?></span></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/admin/main.blade.php ENDPATH**/ ?>