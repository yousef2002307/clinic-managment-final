<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success2')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success2')); ?>

  </div>
<?php endif; ?>

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center mb-5">
                <h2 class="heading-section">Appointments<Scadule</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-wrap">
                    <table class="table table-responsive-xl table-striped">
                      <thead>
                        <tr>
                          
                          <th>Address</th>
                          
                          <th>Date</th>
                          <th>day</th>
                          <th>name</th>
                          <th>price</th>
                          <th>status</th>
                          <th>operation</th>
                          <th>more info</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $appoiment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="alert" role="alert">
                           
                          <td><?php echo e($item->patients->b_no); ?>/<?php echo e($item->patients->street); ?>/<?php echo e($item->patients->city); ?></td>
                          <td><?php echo e($item->date); ?></td>
                          <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('l')); ?></td>
                          <td><?php echo e($item->patients->name); ?></td>
                          <?php if($item->revisit): ?>
                          <td><?php echo e($item->cli->price2); ?></td>
                           <?php else: ?>   
                           <td><?php echo e($item->cli->price); ?></td>
                          <?php endif; ?>
                         <?php if($item->payment_status): ?>
                         <td class="status border-bottom-0"><span class="non-active">Non-paid</span></td>
                         
                          <?php else: ?> 
                          <td class="status"><span class="active">paid</span></td>
                          <?php endif; ?>
                          <td>
                              <button type="button" class="close" >
                                <a class="aclose" href="<?php echo e(url('/resdelete/' . $item->id . '/' . $item->patients->id)); ?>"> <span aria-hidden="true"><i class="fa fa-close"></i></span></a>
                          </button>
                         
                        </td>
                        <td>
                          <a href="<?php echo e(url('/viewinfo2',$item->patients->id)); ?>" class="inf hvr-bounce-to-right theme_btn_two  ">view info</a>
                        </td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--
                        <tr class="alert" role="alert">
                            <td>#1</td>
                          <td>Benha</td>
                          <td>Markotto89</td>
                          <td>12-3-2024</td>
                          <td class="status"><span class="active">Active</span></td>
                          <td>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-close"></i></span>
                          </button>
                          <button type="button" class="edit"  aria-label="edit">
                            <a href="#"><i class="fa fa-edit"></i></a>
                          </button>
                        </td>
                        </tr>
                        <tr class="alert" role="alert">
                            <td>#2</td>
                            <td>Benha</td>
                            <td>Markotto89</td>
                          <td>12-3-2024</td>
                          <td class="status border-bottom-0"><span class="non-active">Non-Active</span></td>
                          <td>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-close"></i></span>
                          </button>
                          <button type="button" class="edit"  aria-label="edit">
                            <a href="#"><i class="fa fa-edit"></i></a>
                          </button>
                        </td>
                        </tr>
                        <tr class="alert" role="alert">
                            <td>#3</td>
                            <td>Benha</td>
                          
                          <td class="border-bottom-0">Markotto89</td>
                          <td>12-3-2024</td>
                          <td class="status border-bottom-0"><span class="waiting">Waiting for Resassignment</span></td>
                          <td class="border-bottom-0" >
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="fa fa-close"></i></span>
                          </button>
                          <button type="button" class="edit"  aria-label="edit">
                            <a href="#"><i class="fa fa-edit"></i></a>
                          </button>
                        </td>
                        </tr>
                    
                    -->
                      </tbody>
                    </table>
                    <?php echo $appoiment->withQueryString()->links('pagination::bootstrap-5'); ?>

                  
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('res.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/res/docappoiments.blade.php ENDPATH**/ ?>