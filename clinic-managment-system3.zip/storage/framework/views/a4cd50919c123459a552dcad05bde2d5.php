
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>


<section class="cliview">
    <div>
    <p>doctor username : <?php echo e($count ? $doctor->username : ''); ?></p>
    </div>
    <div>
        <p>clinic rating: <?php echo e($count ? ($doctor->numofrating? $doctor->numofrating / $doctor->rating : 0)  : ''); ?></p>
    </div>
    <div>
        <p>joined AT: <?php echo e($cli->created_at); ?> </p>
    </div>
    <div>
        <p>num of visits acceptable: <?php echo e($cli->numofvisits); ?> </p>
    </div>
    <div>
        <p>profits made :<?php echo e($count ? $doctor->profits : ''); ?> </p>
    </div>
    <div>
        <p>price of clinic :<?php echo e($cli->price); ?> </p>
    </div>
    <div>
        <p>doctor name : <?php echo e($count ? $doctor->name : ''); ?></p>
    </div>
    <div>
        <p>clinic phone : <?php echo e($cli->phone); ?> </p>
    </div>
    <div class="pend">
        <?php if($cli->pending): ?>
        <a href="<?php echo e(url("/adminactivatecli/$cli->id")); ?>" class="btn">activate</a>
        <?php else: ?>
        
        <a href="<?php echo e(url("/adminpendingcli/$cli->id")); ?>" class="btn">disable this clininc for review</a>
        <?php endif; ?>
        <a class="aclose" href='<?php echo e(url("/adminclidel/$cli->id")); ?>'>delete</a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/admin/cliview.blade.php ENDPATH**/ ?>