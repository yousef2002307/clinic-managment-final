
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php
    $arr = array(
        "1" => "Prescription Fraud",
        "2" => "Billing Fraud",
        "3" => "Unlicensed Practices",
        "4" => "False Advertising",
        "5" => "Overcharging"
);
?>
<h2 class="text-center mt-5 mb-5">available reports</h2>

   
    
 
    <?php $__currentLoopData = $cli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <?php
      $cli = DB::select('select * from patient where id = ? LIMIT 1', [$item->patient_id]);
    ?>
      <p> <?php echo e($arr[$item->val]); ?></p>
      <span><?php echo e($item->created_at); ?></span>
      <p>name of user : <a href="<?php echo e(url("/admincliview2/$item->patient_id")); ?>"> <?php echo e($cli[0]->username); ?></a></p>
        <hr style="background-color: brown"/>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   
    
      
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/admin/reports2.blade.php ENDPATH**/ ?>