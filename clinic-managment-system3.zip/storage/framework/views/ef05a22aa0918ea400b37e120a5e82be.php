<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<section class="courses">

    <h1 class="heading">patientinfo</h1>

    <div class="box-container mb-3">

<div class="box">
    <div class="tutor">
       
      
     
       <div class="title">
          <h3>previouse disease</h3>
          <!-- <span>21-10-2022</span> -->
       </div>
      
    </div>
    <p>
        <?php if(!count($disease)): ?>
            no data available
        <?php else: ?>
        <?php $__currentLoopData = $disease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span><?php echo e($item->disease); ?></span> -
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       
     
     </p>
     <?php if(!count($disease2)): ?>
     users notes about his past  :no data available
 <?php else: ?>
     <p ><strong style="color: #ccc; font-weight:bold;font-size:30px" class="xt"> users notes about his past  : </strong>   <?php echo e($disease2[0]->notes); ?></p>

     <?php endif; ?>
    <!-- <div class="thumb">
       <img src="images/thumb-1.png" alt="">
       <span>10 videos</span>
    </div> -->
  
 
  
 </div>

  
    </div>

    <div class="box-container">

       
              
         <div class="box">
            <div class="tutor">
               
              
             
               <div class="title">
                  <h3>previouse precraption</h3>
                  
               </div>
              
            </div>
            <?php if(!count($prec)): ?>
            no data available
        <?php else: ?>
        <?php $__currentLoopData = $prec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="d-block mb-3"><?php echo e($item->created_at); ?></span> 
            <p class="mb-3">
              <strong style="color: #ccc; font-weight:bold;font-size:30px" class="xt"> notes : </strong> <p><?php echo e($item->notes); ?></p>
             </p>

             <p class="mb-3">
               <strong style="color: #ccc; font-weight:bold;font-size:30px" class="xt"> precraption : </strong>  <p><?php echo e($item->desc2); ?></p>
              </p>
              <hr/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       
            
         </div>
        
         
            </div>
  
 </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/cli/viewinfo.blade.php ENDPATH**/ ?>