<?php $__env->startSection('home'); ?>
<section class="home py-4">
    <div class="overlay"></div>
<nav class="j-home">
    <ul class="j-home-nav">
        <li><a href="<?php echo e(url('/')); ?>">home</a></li>
        <li ><a href="<?php echo e(url('/about')); ?>">about-us</a></li>
        <li ><a href="<?php echo e(url('/serv')); ?>">services</a></li>
        <li ><a href="<?php echo e(url('/contact')); ?>">contact-us</a></li>
        
    </ul>
 </nav>
 <h4 class="title"  style="position: fixed;
z-index: 6;
color: #fff;
top: 40px;
left: 20px;
font-size: 15px;">heart clinic managment system</h4>
<div class="content py-5" style="position: relative;z-index:6;color:#fff">
   <form action="<?php echo e(url('/contact')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <h2 class="text-center">contact-us</h2>
    <div class="container text-center">
   
    <input type="email" name="email" id="" class="form-control mb-3" placeholder="write email here"/>
    <textarea name="message" id="" cols="30" rows="10" class="form-control mb-3">
        write your message here
    </textarea>
    <input type="submit" value="send" class="btn btn-dark text-white">
   </form>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/contact.blade.php ENDPATH**/ ?>