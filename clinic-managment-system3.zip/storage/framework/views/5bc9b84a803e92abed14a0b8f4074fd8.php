
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

<?php if(!$count): ?>
<div class="alert alert-danger">
    to report clinic you have to be examined by it first
</div>
<?php else: ?> 


<section class="report2">
    <div class="container">
        <h1 class="text-center mb-5">report clinic</h1>
        <form action="<?php echo e(url('/report')); ?>" method="POST">
            <?php echo method_field("post"); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Prescription Fraud</label>
                <input type="radio" name="ch" value="1" checked>
            </div>
            <div class="form-group">
                <label for="">Billing Fraud</label>
                <input type="radio" name="ch" value="2">
            </div>
            <div class="form-group">
                <label for="">Unlicensed Practices</label>
                <input type="radio" name="ch" value="3">
            </div>
            <div class="form-group">
                <label for="">False Advertising</label>
                <input type="radio" name="ch" value="4">
            </div>
            <div class="form-group">
                <label for="">Overcharging</label>
                <input type="radio" name="ch" value="5" >
            </div>
            <input type="hidden" name="hidden" value="<?php echo e($id); ?>"/>
            <input type="submit" class="btn btn-lg btn=primary" value="submit">
        </form>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/users/report.blade.php ENDPATH**/ ?>