
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<h2 class="text-center mt-5 mb-5">choose clinic</h2>
<form action="<?php echo e(url('/adminreports')); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    <?php echo method_field("post"); ?>
   
    
   <select class="form-control mb-4" name="clinic" id="">
    <?php $__currentLoopData = $cli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
   
    
      
    <button type="submit" class="btn btn-primary">choose</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/admin/reports.blade.php ENDPATH**/ ?>