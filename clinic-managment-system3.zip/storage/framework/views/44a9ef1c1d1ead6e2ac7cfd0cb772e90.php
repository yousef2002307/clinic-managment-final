
<?php $__env->startSection('con'); ?>
<?php if(isset($error)): ?>
<div class='alert alert-danger'><?php echo e($error); ?>  </div>
<?php endif; ?>
<?php if(isset($success)): ?>
<div class='alert alert-success'><?php echo e($success); ?>  </div>
<?php endif; ?>
<script>
    setTimeout(function() {
       
    window.location.href = "<?php echo e(url()->previous()); ?>";  // Replace with your desired route
    }, 2000); // Delay in milliseconds (5 seconds in this case)
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('cli.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/redirect3.blade.php ENDPATH**/ ?>