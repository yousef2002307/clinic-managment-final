<?php $__env->startSection('con'); ?>
<section class="pt-5 sec5">
<h5 class="text-center my-4">enter your current or prev disease so doctor can benefit from this info and anu medical info</h5>
<form action="<?php echo e(url('/usermed2')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('post'); ?>
    <div class="xz">
    <?php if(!count($disease)): ?>
    <input style="font-size: 20px;width:90%;display:inline-block" class="form-control mb-3" type="text" name="disease1"/>
    <?php else: ?>
        <?php $__currentLoopData = $disease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input style="font-size: 20px;width:90%;display:inline-block" value="<?php echo e($item->disease); ?>" class="form-control mb-3" type="text" name="disease<?php echo e($key+1); ?>"/>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
   
</div>
    <a class="add mb-3 mt-3" style="cursor: pointer"><i class="fa-solid fa-plus"></i></a>
    <?php if(count($disease2)): ?>
    <textarea style="font-size: 22px"  class="form-control mb-3 mt-5" name="note" id="" cols="30" rows="10"><?php echo e($disease2[0]->notes); ?></textarea>
    
    <?php else: ?>
    <textarea style="font-size: 22px"  class="form-control mb-3 mt-5" name="note" id="" cols="30" rows="10"></textarea>
      
    <?php endif; ?>
  
    <input type="submit" value="add" class="btn btn-primary btn-lg d-block">
</form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/users/medical.blade.php ENDPATH**/ ?>