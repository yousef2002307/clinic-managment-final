
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert-danger">
      <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<main id="main">

    <!-- ======= About Section ======= -->
    <section id="edit" class="edit">
       <div class="container">
        <?php if(!session('success2')): ?>
       <div class="alert alert-danger">to continue using the system you must full all your info</div>
       <?php endif; ?>
       <form action="<?php echo e(route('user-upd.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
    
        
        <div class="form-group">
            
            <input value="<?php echo e($patient->password); ?>" type="hidden" name="password2" class="form-control" id="exampleInputPassword1" placeholder="Password">
          </div>
       
       
          <input type="hidden" name="hidden" value="<?php echo e($patient->id); ?>">
          <div class="form-group">
            <label for="exampleInputEmail1">name</label>
            <input value="<?php echo e($patient->name); ?>" required type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name">
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">username</label>
            <input value="<?php echo e($patient->username); ?>" required type="text" name="username" class="form-control" id="exampleInputPassword1" placeholder="username">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">b_no</label>
            <input value="<?php echo e($patient->b_no); ?>" required name="b_no" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter b_no">
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">street</label>
            <input value="<?php echo e($patient->street); ?>" type="text" class="form-control" id="exampleInputPassword1" name="street" required placeholder="street">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">city</label>
            <input value="<?php echo e($patient->city); ?>" required name="city" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="city">
            
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">phone</label>
            <input value="<?php echo e($patient->phone); ?>" type="number" name="phone" required class="form-control" id="exampleInputPassword1" placeholder="phone">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">creditcardnumber</label>
            <input value="<?php echo e($patient->creditcardnumber); ?>"  name="creditcardnumber" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter creditcardnumber">
           
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">cvc</label>
            <input value="<?php echo e($patient->ccv); ?>"  type="number" name="cvc" class="form-control" id="exampleInputPassword1" placeholder="cvc">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">cardtype</label>
            <select style="display:block" name="creditCardType" class="form-control" required>
                <option value="visa" <?php echo e($patient->cardtype == "visa" ? "selected" : ""); ?>>Visa</option>
                <option value="mastercard" <?php echo e($patient->cardtype == "mastercard" ? "selected" : ""); ?>>Mastercard</option>
                
              </select>
          </div>
          
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
       </div>
       </section>
       </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/users/edit2.blade.php ENDPATH**/ ?>