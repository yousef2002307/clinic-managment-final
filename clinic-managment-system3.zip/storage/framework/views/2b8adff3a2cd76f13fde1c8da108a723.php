
<?php $__env->startSection('con'); ?>
<?php if($errors->any()): ?>
<?php echo implode('', $errors->all('<div class="alert alert-danger">:message</div>')); ?>

<?php endif; ?>
<?php if(session('success')): ?>
  <div class="alert alert-success">
      <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

<main id="main">

    <!-- ======= About Section ======= -->
    <section id="edit" class="edit">
       <div class="container">
       <h2 class="text-center">edit profile</h2>
       <form action="<?php echo e(route('editadmin')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("post"); ?>
       
        
        <div class="form-group">
            <label for="exampleInputPassword1">username</label>
            <input value="<?php echo e($patient->username); ?>" required type="text" name="username" class="form-control" id="exampleInputPassword1" placeholder="username">
          </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input value="<?php echo e($patient->password); ?>" type="password" name='password' class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
      

       
        
          
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
       </div>
       </section>
       </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system2\resources\views/admin/edit.blade.php ENDPATH**/ ?>