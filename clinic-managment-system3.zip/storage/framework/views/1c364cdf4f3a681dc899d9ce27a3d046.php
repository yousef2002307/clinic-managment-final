<?php $__env->startSection('home'); ?>
<section class="home py-4">
    <div class="overlay"></div>
<nav class="j-home">
    <ul class="j-home-nav">
        <li><a href="<?php echo e(url('/')); ?>">home</a></li>
        <li ><a href="<?php echo e(url('/about')); ?>">about-us</a></li>
        <li ><a href="<?php echo e(url('/serv')); ?>">services</a></li>
        <li ><a href="<?php echo e(url('/contact')); ?>">contact-us</a></li>
        
    </ul>
 </nav>
<h4 class="title"  style="position: fixed;
z-index: 6;
color: #fff;
top: 40px;
left: 20px;
font-size: 15px;">heart clinic managment system</h4>
 <div class="j-buttons ">
   
    <button><a href="<?php echo e(route("user-login")); ?>">login as patient</a></button>
    <button><a href="<?php echo e(route("Cli-login")); ?>">login as clinic</a></button>
 </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinic-managment-system3\resources\views/home.blade.php ENDPATH**/ ?>